# Archive provenance

Recovered from the original `Capstone_BBO_Week2_UCB_only.zip` created on 30 July 2026.

The original package also contained programme-supplied seed arrays and source ZIP files. Those files are deliberately omitted from this public GitHub copy because redistribution rights have not been established. The participant-created notebook, script, results and Week 1 portal records are preserved unchanged.
