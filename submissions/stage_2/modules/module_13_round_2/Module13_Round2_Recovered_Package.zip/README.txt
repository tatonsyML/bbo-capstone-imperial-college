CAPSTONE BBO — WEEK 2: COURSE-ALIGNED UCB VERSION

This package replaces the earlier mixed-method package.

It uses only:
- Gaussian Process surrogate modelling
- predicted mean
- prediction uncertainty
- Upper Confidence Bound
- grid search for two-dimensional functions
- random candidate search for higher dimensions

Main file:
Capstone_BBO_Week2_UCB_only.ipynb

Supporting files:
- week2_ucb_results.csv
- week2_ucb_portal_values.txt
- source_data/

The kappa choices are documented heuristics:
higher values encourage exploration; lower values encourage exploitation.
